# Empty __init__.py for tests package
# This allows test discovery to work properly 