"""
Model module for ValkyrieLLM containing the core model components and reasoning capabilities.
"""

from .reasoning import ChainOfThoughtReasoner 