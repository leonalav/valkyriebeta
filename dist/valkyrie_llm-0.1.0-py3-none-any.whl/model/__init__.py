"""
Core model components for Valkyrie LLM.
"""

from .core_model import CoreModel

__version__ = "0.2.0"