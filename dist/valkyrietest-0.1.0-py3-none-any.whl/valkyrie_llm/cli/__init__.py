"""
Command-line interface for Valkyrie LLM.
""" 