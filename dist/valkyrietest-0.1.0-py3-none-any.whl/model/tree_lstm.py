import torch
import torch.nn as nn

class TreeLSTMCell(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        
        # Input transformations
        self.ioux = nn.Linear(input_size, 3 * hidden_size)
        self.iouh = nn.Linear(hidden_size, 3 * hidden_size)
        
        # Forget gate transformations
        self.fx = nn.Linear(input_size, hidden_size)
        self.fh = nn.Linear(hidden_size, hidden_size)
        
        # Output transformation
        self.output = nn.Linear(hidden_size, hidden_size)
        
    def forward(self, x, h_prev=None, c_prev=None):
        if h_prev is None:
            batch_size = x.size(0)
            h_prev = torch.zeros(batch_size, self.hidden_size, device=x.device)
            c_prev = torch.zeros(batch_size, self.hidden_size, device=x.device)
            
        # Input, output and update gates
        iou = self.ioux(x) + self.iouh(h_prev)
        i, o, u = torch.split(iou, self.hidden_size, dim=-1)
        i, o, u = torch.sigmoid(i), torch.sigmoid(o), torch.tanh(u)
        
        # Forget gate for each child
        f = torch.sigmoid(self.fx(x) + self.fh(h_prev))
        
        # Update cell state
        c = i * u + f * c_prev
        
        # Update hidden state
        h = o * torch.tanh(c)
        
        return h, c

class TreeLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, max_depth=8, dropout=0.1):
        super().__init__()
        self.hidden_size = hidden_size
        self.max_depth = max_depth
        
        # Use the existing TreeLSTMCell
        self.cell = TreeLSTMCell(input_size, hidden_size)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x, tree_structure=None):
        """Process input either sequentially or in tree structure"""
        if tree_structure is None:
            # Sequential processing
            batch_size, seq_len, _ = x.size()
            h, c = None, None
            
            # Process sequence
            for t in range(seq_len):
                h, c = self.cell(x[:, t], h, c)
                h = self.dropout(h)
            
            return h
        
        # Tree-structured processing
        batch_size = x.size(0)
        h_list = []
        c_list = []
        
        for node in tree_structure:
            if isinstance(node, int):  # Leaf node
                h, c = self.cell(x[:, node])
            else:  # Internal node with children
                child_h = torch.stack([h_list[i] for i in node])
                child_c = torch.stack([c_list[i] for i in node])
                
                # Combine children states
                h_combined = torch.mean(child_h, dim=0)
                c_combined = torch.mean(child_c, dim=0)
                
                # Process current node
                h, c = self.cell(x[:, node[-1]], h_combined, c_combined)
            
            h = self.dropout(h)
            h_list.append(h)
            c_list.append(c)
        
        return h_list[-1]  # Return final state     