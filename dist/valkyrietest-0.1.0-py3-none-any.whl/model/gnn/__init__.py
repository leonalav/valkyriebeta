"""
GNN components for Valkyrie LLM.
"""

# Empty __init__.py file to avoid import errors 