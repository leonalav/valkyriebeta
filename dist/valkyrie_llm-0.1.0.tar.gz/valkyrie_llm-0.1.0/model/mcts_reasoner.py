"""
Monte Carlo Tree Search (MCTS) Reasoner for deep learning models.
This module provides MCTS-based reasoning capabilities for LLMs and transformers.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import numpy as np
import random
from typing import Dict, List, Optional, Tuple, Union, Any, Callable
import logging
from dataclasses import dataclass
from collections import defaultdict

logger = logging.getLogger(__name__)

@dataclass
class MCTSConfig:
    """Configuration for MCTS reasoner"""
    hidden_size: int = 768
    max_simulations: int = 50
    min_simulations: int = 10
    exploration_weight: float = 1.0
    value_scale: float = 2.0
    use_policy_network: bool = True
    use_value_network: bool = True
    temperature: float = 1.0
    max_search_depth: int = 5
    use_adaptive_simulation_count: bool = True
    confidence_threshold: float = 0.9
    use_dirichlet_noise: bool = True
    dirichlet_alpha: float = 0.3
    dirichlet_weight: float = 0.25
    prune_suboptimal_actions: bool = True
    use_simulation_optimization: bool = True
    simulation_batch_size: int = 16
    use_state_compression: bool = False
    enable_progressive_widening: bool = False
    store_reasoning_trace: bool = True

class MCTSNode:
    """
    Node in the MCTS search tree.
    Tracks statistics for action selection and value estimation.
    """
    
    def __init__(self, state=None, action=None, parent=None, prior=0.0):
        self.state = state
        self.action = action  # Action that led to this state
        self.parent = parent
        self.prior = prior  # Prior probability from policy network
        
        # MCTS statistics
        self.visit_count = 0
        self.value_sum = 0.0
        self.children = {}  # Maps actions to child nodes
        self.reward = 0.0  # Immediate reward for reaching this state
        self.expanded = False
        
        # For progressive widening (if enabled)
        self.available_actions = []
        self.unexplored_actions = []
        
        # For reasoning trace
        self.reasoning_steps = []
    
    @property
    def value(self):
        """Average value of this node"""
        if self.visit_count == 0:
            return 0.0
        return self.value_sum / self.visit_count
    
    def add_exploration_noise(self, dirichlet_alpha, dirichlet_weight):
        """Add Dirichlet noise to prior probabilities for exploration"""
        actions = list(self.children.keys())
        noise = np.random.dirichlet([dirichlet_alpha] * len(actions))
        
        for action, n in zip(actions, noise):
            child = self.children[action]
            child.prior = child.prior * (1 - dirichlet_weight) + n * dirichlet_weight
    
    def select_child(self, exploration_weight):
        """Select child node using UCB formula"""
        # Calculate UCB score for each child
        ucb_scores = {
            action: self._ucb_score(child, exploration_weight)
            for action, child in self.children.items()
        }
        
        # Select action with highest UCB score
        action = max(ucb_scores.items(), key=lambda x: x[1])[0]
        return action, self.children[action]
    
    def _ucb_score(self, child, exploration_weight):
        """Calculate UCB score for a child node"""
        # Exploration bonus
        exploration = exploration_weight * child.prior * math.sqrt(self.visit_count) / (child.visit_count + 1)
        
        # Value component
        if child.visit_count == 0:
            value = 0.0
        else:
            value = child.value
        
        return value + exploration
    
    def expand(self, state, actions, priors, rewards=None):
        """Expand node with given actions and their prior probabilities"""
        self.expanded = True
        self.state = state
        self.available_actions = actions.copy()
        self.unexplored_actions = actions.copy()
        
        # Initialize children with prior probabilities
        for i, action in enumerate(actions):
            prior = priors[i] if priors is not None else 1.0 / len(actions)
            reward = rewards[i] if rewards is not None else 0.0
            self.children[action] = MCTSNode(
                state=None,  # State will be determined when this child is selected
                action=action,
                parent=self,
                prior=prior
            )
            self.children[action].reward = reward
    
    def update(self, value):
        """Update node statistics with backpropagated value"""
        self.visit_count += 1
        self.value_sum += value
        
    def record_reasoning_step(self, message):
        """Record a reasoning step for explainability"""
        self.reasoning_steps.append(message)
    
    def get_visit_count_distribution(self):
        """Get distribution of visit counts for all children"""
        if not self.children:
            return []
        
        # Get visit counts for all actions
        visits = np.array([child.visit_count for child in self.children.values()])
        
        # Normalize to get distribution
        if visits.sum() > 0:
            distribution = visits / visits.sum()
        else:
            distribution = np.ones_like(visits) / len(visits)
            
        return distribution.tolist()


class MCTSReasoner(nn.Module):
    """
    Monte Carlo Tree Search reasoning module for enhanced decision making.
    
    This module uses MCTS to simulate future states and explore different reasoning paths,
    allowing for more strategic and long-term thinking in language models.
    """
    
    def __init__(self, config: MCTSConfig = None, **kwargs):
        """
        Initialize the MCTS reasoner.
        
        Args:
            config: MCTS configuration
            **kwargs: Additional parameters to override config
        """
        super().__init__()
        self.config = config or MCTSConfig()
        
        # Override config with kwargs
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        
        # Policy network for action prior probabilities
        if self.config.use_policy_network:
            self.policy_network = nn.Sequential(
                nn.Linear(self.config.hidden_size, self.config.hidden_size),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(self.config.hidden_size, self.config.hidden_size // 2)
            )
        else:
            self.policy_network = None
        
        # Value network for state evaluation
        if self.config.use_value_network:
            self.value_network = nn.Sequential(
                nn.Linear(self.config.hidden_size, self.config.hidden_size),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(self.config.hidden_size, 1),
                nn.Tanh()  # Output in [-1, 1] range
            )
        else:
            self.value_network = None
        
        # State compression for memory efficiency (optional)
        if self.config.use_state_compression:
            self.state_encoder = nn.Sequential(
                nn.Linear(self.config.hidden_size, self.config.hidden_size // 2),
                nn.GELU(),
                nn.Linear(self.config.hidden_size // 2, self.config.hidden_size // 4)
            )
            
            self.state_decoder = nn.Sequential(
                nn.Linear(self.config.hidden_size // 4, self.config.hidden_size // 2),
                nn.GELU(),
                nn.Linear(self.config.hidden_size // 2, self.config.hidden_size)
            )
        
        # Confidence predictor for adaptive simulation count
        if self.config.use_adaptive_simulation_count:
            self.confidence_predictor = nn.Sequential(
                nn.Linear(self.config.hidden_size, self.config.hidden_size // 2),
                nn.GELU(),
                nn.Linear(self.config.hidden_size // 2, 1),
                nn.Sigmoid()
            )
        
        # Statistics tracking
        self.register_buffer('total_simulations', torch.tensor(0))
        self.register_buffer('total_searches', torch.tensor(0))
        self.register_buffer('total_nodes_created', torch.tensor(0))
        
        # For analysis
        self.last_reasoning_trace = []
        self.last_search_statistics = {}
    
    def forward(
        self,
        state: torch.Tensor,
        available_actions: List[Any],
        action_embeddings: Optional[torch.Tensor] = None,
        transition_fn: Optional[Callable] = None,
        reward_fn: Optional[Callable] = None,
        constraints: Optional[Dict[str, Any]] = None
    ):
        """
        Perform MCTS reasoning to select the best action.
        
        Args:
            state: Current state representation [batch_size, hidden_size]
            available_actions: List of available actions
            action_embeddings: Tensor of action embeddings [num_actions, hidden_size]
            transition_fn: Function to get next state given state and action
            reward_fn: Function to compute reward for a state
            constraints: Optional constraints on the search (e.g., max_depth)
            
        Returns:
            Tuple of (selected actions, action probabilities, search info)
        """
        batch_size = state.size(0)
        device = state.device
        
        # Default functions if not provided
        if transition_fn is None:
            # Simple default transition function
            transition_fn = lambda s, a: s + 0.1 * a
        
        if reward_fn is None:
            # Default reward function returns 0
            reward_fn = lambda s: torch.zeros(s.size(0), device=s.device)
        
        # Get action embeddings if not provided
        if action_embeddings is None and isinstance(available_actions[0], str):
            # Create simple embeddings based on token IDs or hashes
            action_ids = [hash(str(a)) % 10000 for a in available_actions]
            action_embeddings = torch.randn(len(available_actions), self.config.hidden_size, device=device)
            action_embeddings = F.normalize(action_embeddings, dim=-1)
        
        # Process batch items one by one (can be optimized for parallel execution)
        selected_actions = []
        action_probs = []
        search_info = []
        
        for i in range(batch_size):
            # Get state for this batch item
            state_i = state[i].unsqueeze(0)  # [1, hidden_size]
            
            # Determine number of simulations based on confidence if adaptive
            if self.config.use_adaptive_simulation_count:
                confidence = self.confidence_predictor(state_i).item()
                num_simulations = max(
                    self.config.min_simulations,
                    min(
                        self.config.max_simulations,
                        int(self.config.max_simulations * (1 - confidence))
                    )
                )
            else:
                num_simulations = self.config.max_simulations
            
            # Run MCTS search
            root = self._run_mcts(
                state_i,
                available_actions,
                action_embeddings,
                transition_fn,
                reward_fn,
                num_simulations
            )
            
            # Get action probabilities based on visit counts
            visit_counts = np.array([
                root.children[a].visit_count for a in available_actions if a in root.children
            ])
            
            # Apply temperature
            if self.config.temperature > 0:
                visit_counts = visit_counts ** (1 / self.config.temperature)
            
            # Normalize to get probabilities
            if visit_counts.sum() > 0:
                probs = visit_counts / visit_counts.sum()
            else:
                probs = np.ones_like(visit_counts) / len(visit_counts)
            
            # Select action (most visited during search)
            best_idx = int(np.argmax(visit_counts))
            selected_action = available_actions[best_idx]
            
            # Collect results
            selected_actions.append(selected_action)
            action_probs.append(probs)
            
            # Collect search info
            info = {
                'num_simulations': num_simulations,
                'num_nodes': self.total_nodes_created.item(),
                'visit_counts': visit_counts.tolist(),
                'reasoning_trace': root.reasoning_steps if self.config.store_reasoning_trace else []
            }
            search_info.append(info)
            
            # Store for analysis
            self.last_reasoning_trace = root.reasoning_steps
            self.last_search_statistics = info
            
            # Update statistics
            self.total_simulations += num_simulations
            self.total_searches += 1
        
        return selected_actions, action_probs, search_info
    
    def _run_mcts(
        self,
        root_state: torch.Tensor,
        available_actions: List[Any],
        action_embeddings: torch.Tensor,
        transition_fn: Callable,
        reward_fn: Callable,
        num_simulations: int
    ) -> MCTSNode:
        """
        Run Monte Carlo Tree Search from the given state.
        
        Args:
            root_state: Starting state representation
            available_actions: List of available actions
            action_embeddings: Embeddings for actions
            transition_fn: Function to get next state
            reward_fn: Function to compute rewards
            num_simulations: Number of simulations to perform
            
        Returns:
            Root node of the search tree after simulations
        """
        # Initialize root node
        root = MCTSNode(state=root_state)
        
        # Expand root node
        self._expand_node(root, available_actions, action_embeddings)
        
        # Add exploration noise to root prior probabilities
        if self.config.use_dirichlet_noise:
            root.add_exploration_noise(
                self.config.dirichlet_alpha,
                self.config.dirichlet_weight
            )
        
        # Record reasoning
        root.record_reasoning_step("Starting MCTS reasoning with root state.")
        
        # Run simulations
        for i in range(num_simulations):
            # Selection phase: Select path through tree
            node = root
            search_path = [node]
            
            # Select until we reach a leaf node
            while node.expanded and node.children:
                action, node = node.select_child(self.config.exploration_weight)
                search_path.append(node)
                
                # Record reasoning
                if self.config.store_reasoning_trace and len(search_path) < 5:  # Limit depth for reasoning trace
                    parent = search_path[-2]
                    parent.record_reasoning_step(
                        f"Selected action '{action}' with UCB score based on value {node.value:.3f} "
                        f"and visit count {node.visit_count}."
                    )
            
            # Leaf node handling
            if not node.expanded:
                # Get state for this node if not already set
                if node.state is None and node.parent is not None:
                    parent_state = node.parent.state
                    action_emb = action_embeddings[available_actions.index(node.action)]
                    node.state = transition_fn(parent_state, action_emb.unsqueeze(0))
                    
                    # Get immediate reward
                    node.reward = reward_fn(node.state).item()
                    
                    # Record reasoning
                    if self.config.store_reasoning_trace:
                        node.record_reasoning_step(
                            f"Expanded node after action '{node.action}' with immediate reward {node.reward:.3f}."
                        )
                
                # Expansion phase: Expand if this node has enough visits
                if node.visit_count > 0 or node == root:
                    self._expand_node(node, available_actions, action_embeddings)
                
                # Evaluate the new state
                value = self._evaluate(node.state)
            else:
                # Rollout phase: Simulate from this state
                value = self._rollout(
                    node.state,
                    available_actions,
                    action_embeddings,
                    transition_fn,
                    reward_fn,
                    depth=0
                )
                
            # Backpropagation phase: Update values up the tree
            self._backpropagate(search_path, value)
        
        return root
    
    def _expand_node(self, node: MCTSNode, available_actions: List[Any], action_embeddings: torch.Tensor):
        """
        Expand a node with all available actions.
        
        Args:
            node: Node to expand
            available_actions: List of available actions
            action_embeddings: Embeddings for actions
        """
        # Skip if already expanded
        if node.expanded:
            return
        
        # Get prior probabilities from policy network if available
        if self.policy_network is not None:
            policy_logits = self.policy_network(node.state)
            
            # Map to available actions
            action_mask = torch.zeros(action_embeddings.size(0), device=action_embeddings.device)
            action_mask[:len(available_actions)] = 1.0
            
            # Apply mask and get probabilities
            masked_logits = policy_logits + (1 - action_mask) * -1e9
            priors = F.softmax(masked_logits / self.config.temperature, dim=-1)
            priors = priors[:len(available_actions)].detach().cpu().numpy()
        else:
            # Uniform prior if no policy network
            priors = np.ones(len(available_actions)) / len(available_actions)
        
        # Get immediate rewards for actions if reward function is available
        rewards = None
        if callable(getattr(self, '_compute_action_rewards', None)):
            rewards = self._compute_action_rewards(
                node.state, 
                available_actions, 
                action_embeddings
            )
        
        # Expand node with these actions
        node.expand(node.state, available_actions, priors, rewards)
        
        # Update node count
        self.total_nodes_created += len(available_actions)
    
    def _evaluate(self, state: torch.Tensor) -> float:
        """
        Evaluate a state using the value network.
        
        Args:
            state: State representation
            
        Returns:
            Estimated value of the state
        """
        if self.value_network is not None:
            with torch.no_grad():
                value = self.value_network(state).item()
                # Scale output to desired range
                value *= self.config.value_scale
        else:
            # Default to zero if no value network
            value = 0.0
            
        return value
    
    def _rollout(
        self,
        state: torch.Tensor,
        available_actions: List[Any],
        action_embeddings: torch.Tensor,
        transition_fn: Callable,
        reward_fn: Callable,
        depth: int = 0
    ) -> float:
        """
        Perform a rollout from the given state to estimate its value.
        
        Args:
            state: Starting state representation
            available_actions: List of available actions
            action_embeddings: Embeddings for actions
            transition_fn: Function to get next state
            reward_fn: Function to compute rewards
            depth: Current depth of rollout
            
        Returns:
            Estimated value from rollout
        """
        # If max depth reached, evaluate state directly
        if depth >= self.config.max_search_depth:
            return self._evaluate(state)
        
        # Select random action for rollout
        action_idx = random.randrange(len(available_actions))
        action_emb = action_embeddings[action_idx]
        
        # Get next state
        next_state = transition_fn(state, action_emb.unsqueeze(0))
        
        # Get reward for this step
        reward = reward_fn(next_state).item()
        
        # Recursive rollout with discount factor
        future_value = self._rollout(
            next_state,
            available_actions,
            action_embeddings,
            transition_fn,
            reward_fn,
            depth + 1
        )
        
        # Combine immediate reward with discounted future value
        gamma = 0.95  # Discount factor
        value = reward + gamma * future_value
        
        return value
    
    def _backpropagate(self, search_path: List[MCTSNode], value: float):
        """
        Backpropagate value through the search path.
        
        Args:
            search_path: List of nodes visited during selection
            value: Value to backpropagate
        """
        # Apply backpropagation with optional transformations
        for node in reversed(search_path):
            node.update(value)
            
            # Include immediate reward in value for parent
            if node.parent is not None:
                value = node.reward + 0.95 * value  # Apply discount
    
    def get_search_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about the search process.
        
        Returns:
            Dictionary with search statistics
        """
        stats = {
            'avg_simulations_per_search': (
                self.total_simulations / max(1, self.total_searches)
            ).item(),
            'total_searches': self.total_searches.item(),
            'total_nodes_created': self.total_nodes_created.item(),
            'avg_nodes_per_search': (
                self.total_nodes_created / max(1, self.total_searches)
            ).item()
        }
        
        return stats
    
    def get_last_reasoning_trace(self) -> List[str]:
        """
        Get the reasoning trace from the last search.
        
        Returns:
            List of reasoning steps
        """
        return self.last_reasoning_trace
    
    def reset_statistics(self):
        """Reset all search statistics"""
        self.total_simulations.zero_()
        self.total_searches.zero_()
        self.total_nodes_created.zero_()
        self.last_reasoning_trace = []
        self.last_search_statistics = {} 