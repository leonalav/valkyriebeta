import torch
import torch.distributed as dist
from typing import Optional, Dict, Any, Tuple, Callable
import logging
from dataclasses import dataclass
import os
import torch.multiprocessing as mp

@dataclass
class DistributedConfig:
    """Configuration for distributed training"""
    world_size: int
    rank: int
    local_rank: int
    backend: str = "nccl"
    master_addr: str = "localhost"
    master_port: str = "12355"

class DistributedHandler:
    def __init__(self, config: DistributedConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def setup(self):
        """Initialize distributed training environment"""
        try:
            torch.cuda.set_device(self.config.local_rank)
            dist.init_process_group(
                backend=self.config.backend,
                init_method=f"tcp://{self.config.master_addr}:{self.config.master_port}",
                world_size=self.config.world_size,
                rank=self.config.rank
            )
            self.logger.info(f"Initialized process group: rank {self.config.rank}/{self.config.world_size}")
        except Exception as e:
            self.logger.error(f"Failed to initialize distributed environment: {e}")
            raise

    def cleanup(self):
        """Cleanup distributed training resources"""
        if dist.is_initialized():
            dist.destroy_process_group()

    def sync_model(self, model: torch.nn.Module):
        """Synchronize model parameters across processes"""
        for param in model.parameters():
            dist.broadcast(param.data, src=0)
            
    def reduce_metrics(self, metrics: Dict[str, torch.Tensor]) -> Dict[str, torch.Tensor]:
        """Reduce metrics across all processes"""
        reduced_metrics = {}
        for name, value in metrics.items():
            if isinstance(value, torch.Tensor):
                dist.all_reduce(value, op=dist.ReduceOp.SUM)
                reduced_metrics[name] = value / self.config.world_size
        return reduced_metrics

    @property
    def is_main_process(self) -> bool:
        """Check if current process is the main process"""
        return self.config.rank == 0

def setup_distributed(
    rank: int,
    world_size: int,
    backend: str = "nccl",
    master_addr: str = "localhost",
    master_port: str = "12355"
) -> Tuple[int, int]:
    """
    Set up distributed training.
    
    Args:
        rank: Process rank
        world_size: Total number of processes
        backend: Distributed backend ('nccl', 'gloo', etc.)
        master_addr: Master address for distributed coordination
        master_port: Master port for distributed coordination
        
    Returns:
        rank: Local process rank
        world_size: Total number of processes
    """
    # Set environment variables
    os.environ["MASTER_ADDR"] = master_addr
    os.environ["MASTER_PORT"] = master_port
    
    # Initialize process group
    dist.init_process_group(backend=backend, rank=rank, world_size=world_size)
    
    # Configure device
    torch.cuda.set_device(rank)
    
    print(f"Initialized process {rank}/{world_size}")
    
    return rank, world_size

def cleanup_distributed():
    """Clean up distributed training resources"""
    if dist.is_initialized():
        dist.destroy_process_group()
        print("Destroyed process group")

def run_distributed(
    fn: Callable,
    world_size: int,
    args: Tuple = (),
    kwargs: Dict[str, Any] = None,
    backend: str = "nccl"
):
    """
    Run a function in a distributed setting.
    
    Args:
        fn: Function to run
        world_size: Total number of processes
        args: Args to pass to the function
        kwargs: Kwargs to pass to the function
        backend: Distributed backend
    """
    kwargs = kwargs or {}
    
    # Check if CUDA is available
    if not torch.cuda.is_available():
        print("CUDA not available, using CPU")
        backend = "gloo"
    
    # Define launcher function
    def _launcher(rank, world_size, args, kwargs):
        # Set up distributed
        rank, world_size = setup_distributed(rank, world_size, backend)
        
        try:
            # Run function
            fn(rank, world_size, *args, **{**kwargs, "rank": rank, "world_size": world_size})
        except Exception as e:
            print(f"Error in process {rank}: {e}")
            raise
        finally:
            # Clean up
            cleanup_distributed()
    
    # Launch processes
    if world_size > 1:
        mp.spawn(
            _launcher,
            args=(world_size, args, kwargs),
            nprocs=world_size,
            join=True
        )
    else:
        # Single process
        _launcher(0, 1, args, kwargs)

def distributed_gather(tensor: torch.Tensor) -> torch.Tensor:
    """
    Gather tensor from all processes.
    
    Args:
        tensor: Tensor to gather
        
    Returns:
        Gathered tensor
    """
    if not dist.is_initialized():
        return tensor
        
    # Get world size
    world_size = dist.get_world_size()
    
    # Create output list
    gathered = [torch.zeros_like(tensor) for _ in range(world_size)]
    
    # Gather
    dist.all_gather(gathered, tensor)
    
    # Concatenate
    return torch.cat(gathered, dim=0)

def distributed_broadcast(tensor: torch.Tensor, src: int = 0) -> torch.Tensor:
    """
    Broadcast tensor from source rank to all processes.
    
    Args:
        tensor: Tensor to broadcast
        src: Source rank
        
    Returns:
        Broadcasted tensor
    """
    if not dist.is_initialized():
        return tensor
        
    # Broadcast
    dist.broadcast(tensor, src=src)
    
    return tensor

def distributed_reduce(tensor: torch.Tensor, op: str = "sum") -> torch.Tensor:
    """
    Reduce tensor across all processes.
    
    Args:
        tensor: Tensor to reduce
        op: Reduction operation ("sum", "avg", "min", "max", "product")
        
    Returns:
        Reduced tensor
    """
    if not dist.is_initialized():
        return tensor
        
    # Get reduce operation
    if op == "sum":
        reduce_op = dist.ReduceOp.SUM
    elif op == "avg":
        reduce_op = dist.ReduceOp.SUM
    elif op == "min":
        reduce_op = dist.ReduceOp.MIN
    elif op == "max":
        reduce_op = dist.ReduceOp.MAX
    elif op == "product":
        reduce_op = dist.ReduceOp.PRODUCT
    else:
        raise ValueError(f"Unsupported reduce operation: {op}")
    
    # Create output tensor
    output = torch.zeros_like(tensor)
    
    # Reduce
    dist.all_reduce(tensor, op=reduce_op, out=output)
    
    # Adjust for average
    if op == "avg":
        output = output / dist.get_world_size()
    
    return output
