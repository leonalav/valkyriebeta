from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Union
import os
import json

@dataclass
class EnhancedTrainingConfig:
    """Enhanced training configuration with support for knowledge distillation, domain-specific data, and computational efficiency"""
    
    # Basic training parameters
    batch_size: int = 32
    eval_batch_size: int = 64
    learning_rate: float = 5e-5
    weight_decay: float = 0.01
    num_epochs: int = 10
    warmup_steps: int = 1000
    gradient_accumulation_steps: int = 1
    max_grad_norm: float = 1.0
    
    # Checkpointing
    checkpoint_interval: int = 1
    save_total_limit: int = 3
    save_strategy: str = "epoch"  # Options: epoch, steps
    save_steps: int = 500
    
    # Evaluation
    eval_strategy: str = "epoch"  # Options: epoch, steps
    eval_steps: int = 500
    
    # Logging
    logging_dir: str = "logs"
    logging_steps: int = 100
    
    # Optimizer
    optimizer_type: str = "adamw"  # Options: adamw, adafactor, sgd, lamb
    scheduler_type: str = "linear"  # Options: linear, cosine, constant, constant_with_warmup
    
    # Mixed precision
    use_mixed_precision: bool = True
    mixed_precision_dtype: str = "float16"  # Options: float16, bfloat16
    
    # Distributed training
    use_distributed_training: bool = False
    local_rank: int = -1
    world_size: int = 1
    
    # NEW: Knowledge Distillation
    use_knowledge_distillation: bool = True
    teacher_model_path: Optional[str] = None
    teacher_model_api: Optional[str] = None
    distillation_alpha: float = 0.5  # Weight for distillation loss vs task loss
    distillation_temperature: float = 2.0
    progressive_distillation: bool = True
    
    # NEW: Domain-specific data
    use_domain_specific_data: bool = True
    domains: List[str] = field(default_factory=lambda: ["general", "math", "science", "logic", "coding"])
    domain_weights: Dict[str, float] = field(default_factory=lambda: {
        "general": 1.0,
        "math": 1.5,
        "science": 1.2,
        "logic": 1.3,
        "coding": 1.4
    })
    domain_data_paths: Dict[str, str] = field(default_factory=dict)
    augment_vocabulary: bool = True
    domain_vocab_files: Dict[str, str] = field(default_factory=dict)
    use_curriculum: bool = True
    mixing_strategy: str = "proportional"  # Options: proportional, equal, curriculum
    
    # NEW: Computational Efficiency
    use_computational_efficiency: bool = True
    use_activation_checkpointing: bool = True
    checkpoint_every_n_layers: int = 2
    use_efficient_attention: bool = True
    attention_implementation: str = "flash"  # Options: flash, memory_efficient, sparse
    use_early_exit: bool = True
    use_adaptive_batch_size: bool = True
    min_batch_size: int = 8
    max_batch_size: int = 64
    use_torch_compile: bool = False
    compile_mode: str = "reduce-overhead"  # Options: default, reduce-overhead, max-autotune
    
    # NEW: Adaptive Reasoning
    use_adaptive_reasoning: bool = True
    
    def __post_init__(self):
        """Initialize default values for paths if not provided"""
        # Set default domain data paths if not provided
        if not self.domain_data_paths:
            self.domain_data_paths = {
                domain: f"data/{domain}" for domain in self.domains
            }
            
        # Set default domain vocab files if not provided
        if not self.domain_vocab_files:
            self.domain_vocab_files = {
                domain: f"data/{domain}/vocab.json" for domain in self.domains
            }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {k: v for k, v in self.__dict__.items()}
    
    def save(self, path: str):
        """Save config to JSON file"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'EnhancedTrainingConfig':
        """Create config from dictionary"""
        return cls(**config_dict)
    
    @classmethod
    def load(cls, path: str) -> 'EnhancedTrainingConfig':
        """Load config from JSON file"""
        with open(path, 'r') as f:
            config_dict = json.load(f)
        return cls.from_dict(config_dict)


@dataclass
class DistillationConfig:
    """Configuration for knowledge distillation"""
    
    # Teacher model
    teacher_model_path: Optional[str] = None
    teacher_model_api: Optional[str] = None
    
    # Distillation parameters
    alpha: float = 0.5  # Weight for distillation loss vs task loss
    temperature: float = 2.0
    
    # What to distill
    distill_logits: bool = True
    distill_hidden_states: bool = True
    distill_attention: bool = True
    
    # Progressive distillation
    use_progressive_distillation: bool = True
    progressive_stages: List[str] = field(default_factory=lambda: ["base", "reasoning", "domain_specific", "fine_tuning"])
    current_stage: str = "base"


@dataclass
class DomainSpecificConfig:
    """Configuration for domain-specific data handling"""
    
    # Domains
    domains: List[str] = field(default_factory=lambda: ["general", "math", "science", "logic", "coding"])
    
    # Domain weights
    domain_weights: Dict[str, float] = field(default_factory=lambda: {
        "general": 1.0,
        "math": 1.5,
        "science": 1.2,
        "logic": 1.3,
        "coding": 1.4
    })
    
    # Data paths
    domain_data_paths: Dict[str, str] = field(default_factory=dict)
    
    # Vocabulary
    augment_vocabulary: bool = True
    domain_vocab_files: Dict[str, str] = field(default_factory=dict)
    
    # Curriculum learning
    use_curriculum: bool = True
    mixing_strategy: str = "proportional"  # Options: proportional, equal, curriculum
    
    # Data augmentation
    augment_low_resource: bool = True
    min_domain_examples: int = 1000


@dataclass
class ComputationalEfficiencyConfig:
    """Configuration for computational efficiency optimizations"""
    
    # Activation checkpointing
    use_activation_checkpointing: bool = True
    checkpoint_every_n_layers: int = 2
    
    # Efficient attention
    use_efficient_attention: bool = True
    attention_implementation: str = "flash"  # Options: flash, memory_efficient, sparse
    
    # Early exit
    use_early_exit: bool = True
    exit_threshold: float = 0.9
    min_layers: int = 4
    
    # Conditional computation
    use_conditional_computation: bool = True
    
    # Mixed precision
    use_mixed_precision: bool = True
    mixed_precision_dtype: str = "float16"  # Options: float16, bfloat16
    
    # Adaptive batch sizes
    use_adaptive_batch_size: bool = True
    min_batch_size: int = 8
    max_batch_size: int = 64
    
    # Compilation
    use_torch_compile: bool = False
    compile_mode: str = "reduce-overhead"  # Options: default, reduce-overhead, max-autotune


@dataclass
class AdaptiveReasoningConfig:
    """Configuration for adaptive reasoning"""
    
    # Complexity thresholds
    low_complexity_threshold: float = 0.3
    medium_complexity_threshold: float = 0.7
    
    # Computation budget
    max_computation_budget: float = 1.0
    min_computation_budget: float = 0.2
    
    # Early exit
    use_early_exit: bool = True
    early_exit_threshold: float = 0.9 