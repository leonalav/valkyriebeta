"""
Adaptive Reasoning module for dynamically adjusting reasoning strategies.

This module provides components that allow the model to adapt its reasoning approach
based on the complexity and type of the problem it's solving.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import logging
from typing import Dict, Any, Optional, List, Union, Tuple
from dataclasses import dataclass
from enum import Enum, auto

logger = logging.getLogger(__name__)

class ReasoningStrategy(Enum):
    """Enum for different reasoning strategies the model can employ."""
    DEFAULT = auto()
    STEP_BY_STEP = auto()
    CHAIN_OF_THOUGHT = auto()
    SYMBOLIC = auto()
    NUMERICAL = auto()
    RETRIEVAL_AUGMENTED = auto()
    ANALOGICAL = auto()
    COMPARATIVE = auto()
    CAUSAL = auto()
    COUNTERFACTUAL = auto()
    ABDUCTIVE = auto()

class AdaptiveReasoningConfig:
    """Configuration for adaptive reasoning capabilities."""
    
    def __init__(
        self,
        enabled=True,
        default_strategy=ReasoningStrategy.DEFAULT,
        strategy_selection_threshold=0.7,
        max_reasoning_steps=10,
        use_meta_learning=False,
        use_reinforcement=False,
        temperature=0.8,
        reasoning_prompt_templates=None,
        strategy_embeddings_size=128,
    ):
        """
        Initialize the adaptive reasoning configuration.
        
        Args:
            enabled: Whether adaptive reasoning is enabled
            default_strategy: Default reasoning strategy to use
            strategy_selection_threshold: Confidence threshold for strategy selection
            max_reasoning_steps: Maximum number of reasoning steps to perform
            use_meta_learning: Whether to use meta-learning for strategy selection
            use_reinforcement: Whether to use reinforcement learning for strategy improvement
            temperature: Temperature for reasoning strategy selection
            reasoning_prompt_templates: Dictionary mapping strategies to prompt templates
            strategy_embeddings_size: Size of the strategy embedding vectors
        """
        self.enabled = enabled
        self.default_strategy = default_strategy
        self.strategy_selection_threshold = strategy_selection_threshold
        self.max_reasoning_steps = max_reasoning_steps
        self.use_meta_learning = use_meta_learning
        self.use_reinforcement = use_reinforcement
        self.temperature = temperature
        self.strategy_embeddings_size = strategy_embeddings_size
        
        # Default reasoning prompt templates
        self._default_templates = {
            ReasoningStrategy.DEFAULT: "",
            ReasoningStrategy.STEP_BY_STEP: "Let's solve this step-by-step:",
            ReasoningStrategy.CHAIN_OF_THOUGHT: "Let's think through this:",
            ReasoningStrategy.SYMBOLIC: "Let's use symbolic reasoning:",
            ReasoningStrategy.NUMERICAL: "Let's solve this numerically:",
            ReasoningStrategy.RETRIEVAL_AUGMENTED: "Let me recall some relevant information:",
            ReasoningStrategy.ANALOGICAL: "This reminds me of a similar problem:",
            ReasoningStrategy.COMPARATIVE: "Let's compare different approaches:",
            ReasoningStrategy.CAUSAL: "Let's analyze the causal relationships:",
            ReasoningStrategy.COUNTERFACTUAL: "Let's consider what would happen if:",
            ReasoningStrategy.ABDUCTIVE: "Let's find the most likely explanation:"
        }
        
        self.reasoning_prompt_templates = reasoning_prompt_templates or self._default_templates

    def __repr__(self):
        return (f"AdaptiveReasoningConfig(enabled={self.enabled}, "
                f"default_strategy={self.default_strategy}, "
                f"max_reasoning_steps={self.max_reasoning_steps})")

class ComplexityEstimator(nn.Module):
    """Estimates the complexity of input text for reasoning"""
    
    def __init__(self, hidden_size: int):
        super().__init__()
        
        # Complexity estimation network
        self.complexity_net = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.GELU(),
            nn.Linear(hidden_size // 2, hidden_size // 4),
            nn.GELU(),
            nn.Linear(hidden_size // 4, 1),
            nn.Sigmoid()
        )
        
        # Features that indicate complexity
        self.complexity_features = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, 5)  # 5 complexity features
        )
        
    def forward(self, hidden_states: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Estimate the complexity of input text
        
        Args:
            hidden_states: Hidden states from the transformer [batch_size, seq_len, hidden_size]
            
        Returns:
            complexity: Complexity score [batch_size, 1]
            features: Complexity features [batch_size, 5]
        """
        # Pool sequence dimension
        pooled = hidden_states.mean(dim=1)  # [batch_size, hidden_size]
        
        # Estimate complexity
        complexity = self.complexity_net(pooled)  # [batch_size, 1]
        
        # Extract complexity features
        features = self.complexity_features(pooled)  # [batch_size, 5]
        
        return complexity, features

class ComponentSelector(nn.Module):
    """Selects which reasoning components to use based on input complexity and available compute"""
    
    def __init__(self, config: AdaptiveReasoningConfig, hidden_size: int):
        super().__init__()
        self.config = config
        
        # Complexity estimator
        self.complexity_estimator = ComplexityEstimator(hidden_size)
        
        # Component selection network
        self.selection_net = nn.Sequential(
            nn.Linear(5 + 1, 64),  # 5 complexity features + 1 complexity score
            nn.GELU(),
            nn.Linear(64, len(config.component_costs))
        )
        
    def forward(
        self, 
        hidden_states: torch.Tensor,
        available_compute: float = 1.0
    ) -> Dict[str, bool]:
        """
        Select which reasoning components to use
        
        Args:
            hidden_states: Hidden states from the transformer [batch_size, seq_len, hidden_size]
            available_compute: Available computation budget (0.0-1.0)
            
        Returns:
            Dictionary mapping component names to whether they should be used
        """
        # Estimate complexity
        complexity, features = self.complexity_estimator(hidden_states)
        complexity = complexity.mean().item()  # Average over batch
        
        # Adjust available compute based on complexity
        adjusted_compute = min(
            self.config.max_computation_budget,
            max(
                self.config.min_computation_budget,
                available_compute * (0.5 + 0.5 * complexity)  # Scale with complexity
            )
        )
        
        # Determine which components to use based on complexity
        if complexity < self.config.low_complexity_threshold:
            # Simple reasoning - use minimal components
            return self._select_components_for_simple_reasoning(adjusted_compute)
        elif complexity < self.config.medium_complexity_threshold:
            # Moderate reasoning - use medium components
            return self._select_components_for_moderate_reasoning(adjusted_compute)
        else:
            # Complex reasoning - use all components if possible
            return self._select_components_for_complex_reasoning(adjusted_compute)
    
    def _select_components_for_simple_reasoning(self, available_compute: float) -> Dict[str, bool]:
        """Select components for simple reasoning tasks"""
        components = {name: False for name in self.config.component_costs}
        
        # Always enable MoE for simple reasoning
        components["moe"] = True
        available_compute -= self.config.component_costs.get("moe", 0)
        
        # Enable memory layer if affordable
        if available_compute >= self.config.component_costs.get("memory_layer", 0):
            components["memory_layer"] = True
            available_compute -= self.config.component_costs.get("memory_layer", 0)
        
        # Enable knowledge reasoning if affordable (useful for factual queries)
        if available_compute >= self.config.component_costs.get("knowledge_reasoning", 0):
            components["knowledge_reasoning"] = True
            available_compute -= self.config.component_costs.get("knowledge_reasoning", 0)
        
        return components
    
    def _select_components_for_moderate_reasoning(self, available_compute: float) -> Dict[str, bool]:
        """Select components for moderate reasoning tasks"""
        components = {name: False for name in self.config.component_costs}
        
        # Sort components by importance for moderate reasoning
        sorted_components = sorted(
            self.config.component_importance.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        # Enable components in order of importance until we run out of compute
        for name, _ in sorted_components:
            if available_compute >= self.config.component_costs.get(name, 0):
                components[name] = True
                available_compute -= self.config.component_costs.get(name, 0)
            else:
                components[name] = False
        
        return components
    
    def _select_components_for_complex_reasoning(self, available_compute: float) -> Dict[str, bool]:
        """Select components for complex reasoning tasks"""
        components = {name: False for name in self.config.component_costs}
        
        # For complex reasoning, try to enable all components
        # If not enough compute, prioritize tree reasoning and neural symbolic
        priority_components = [
            "tree_reasoning",
            "neural_symbolic",
            "recursive_reasoning",
            "moe",
            "knowledge_reasoning",
            "verifiable_computation",
            "memory_layer"
        ]
        
        for name in priority_components:
            if available_compute >= self.config.component_costs.get(name, 0):
                components[name] = True
                available_compute -= self.config.component_costs.get(name, 0)
            else:
                components[name] = False
        
        return components

class AdaptiveReasoningController(nn.Module):
    """
    Controller module for adaptive reasoning capabilities.
    
    This module integrates with a transformer model and provides
    mechanisms to adapt reasoning strategies based on input characteristics.
    """
    
    def __init__(self, config, hidden_size, vocab_size):
        """
        Initialize the adaptive reasoning controller.
        
        Args:
            config: AdaptiveReasoningConfig object
            hidden_size: Size of hidden states in the transformer model
            vocab_size: Size of vocabulary in the model
        """
        super().__init__()
        self.config = config
        self.hidden_size = hidden_size
        self.vocab_size = vocab_size
        
        # Create strategy embeddings
        num_strategies = len(ReasoningStrategy)
        self.strategy_embeddings = nn.Embedding(
            num_strategies, 
            config.strategy_embeddings_size
        )
        
        # Strategy selection network
        self.strategy_selector = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size // 2, num_strategies)
        )
        
        # Strategy integration layer
        self.strategy_integration = nn.Linear(
            hidden_size + config.strategy_embeddings_size, 
            hidden_size
        )
        
        # Reasoning step counter
        self.register_buffer('reasoning_steps', torch.zeros(1, dtype=torch.long))
        
        # Current strategy tracker
        self.current_strategy = config.default_strategy
        
        # Strategy effectiveness tracking
        self.strategy_scores = {strategy: 0.0 for strategy in ReasoningStrategy}
        self.strategy_uses = {strategy: 0 for strategy in ReasoningStrategy}
        
        logger.info(f"Initialized AdaptiveReasoningController with {num_strategies} strategies")
    
    def reset_state(self):
        """Reset the reasoning state."""
        self.reasoning_steps.zero_()
        self.current_strategy = self.config.default_strategy
    
    def select_strategy(self, hidden_states, problem_type=None):
        """
        Select an appropriate reasoning strategy based on the hidden states.
        
        Args:
            hidden_states: Hidden states from the transformer model
            problem_type: Optional explicit problem type hint
            
        Returns:
            The selected reasoning strategy
        """
        if not self.config.enabled:
            return self.config.default_strategy
            
        # Use the mean pooled hidden state for strategy selection
        pooled_hidden = hidden_states.mean(dim=1)
        
        # Get strategy logits
        strategy_logits = self.strategy_selector(pooled_hidden)
        
        # Apply temperature
        strategy_logits = strategy_logits / self.config.temperature
        
        # Convert to probabilities
        strategy_probs = torch.softmax(strategy_logits, dim=-1)
        
        # Get the most likely strategy
        max_prob, max_idx = strategy_probs.max(dim=-1)
        
        # Use default strategy if confidence is too low
        if max_prob.item() < self.config.strategy_selection_threshold:
            selected_strategy = self.config.default_strategy
        else:
            selected_strategy = ReasoningStrategy(max_idx.item() + 1)  # +1 because Enum starts at 1
        
        # Override with explicit problem type if provided
        if problem_type is not None:
            if problem_type == "math":
                selected_strategy = ReasoningStrategy.NUMERICAL
            elif problem_type == "logic":
                selected_strategy = ReasoningStrategy.SYMBOLIC
            elif problem_type == "causal":
                selected_strategy = ReasoningStrategy.CAUSAL
                
        # Update current strategy
        self.current_strategy = selected_strategy
        self.strategy_uses[selected_strategy] += 1
        
        return selected_strategy
    
    def get_reasoning_prompt(self, strategy=None):
        """
        Get the reasoning prompt template for the given strategy.
        
        Args:
            strategy: The reasoning strategy to get a prompt for
            
        Returns:
            The prompt template string
        """
        strategy = strategy or self.current_strategy
        return self.config.reasoning_prompt_templates.get(
            strategy, 
            self.config.reasoning_prompt_templates[ReasoningStrategy.DEFAULT]
        )
    
    def integrate_strategy(self, hidden_states, strategy=None):
        """
        Integrate the strategy embedding into the hidden states.
        
        Args:
            hidden_states: Hidden states from the transformer model
            strategy: The reasoning strategy to integrate
            
        Returns:
            Modified hidden states with strategy integration
        """
        if not self.config.enabled:
            return hidden_states
            
        strategy = strategy or self.current_strategy
        strategy_idx = torch.tensor([strategy.value - 1], device=hidden_states.device)  # -1 because Enum starts at 1
        strategy_embedding = self.strategy_embeddings(strategy_idx)
        
        # Expand strategy embedding to match hidden states shape
        batch_size, seq_len, _ = hidden_states.shape
        strategy_embedding = strategy_embedding.expand(batch_size, seq_len, -1)
        
        # Concatenate hidden states with strategy embedding
        augmented_hidden = torch.cat([hidden_states, strategy_embedding], dim=-1)
        
        # Integrate strategy into hidden states
        integrated_hidden = self.strategy_integration(augmented_hidden)
        
        # Increment reasoning step counter
        self.reasoning_steps += 1
        
        return integrated_hidden
    
    def update_strategy_score(self, strategy, score):
        """
        Update the effectiveness score for a strategy.
        
        Args:
            strategy: The reasoning strategy to update
            score: Score indicating how effective the strategy was
        """
        if strategy in self.strategy_scores:
            # Exponential moving average
            alpha = 0.1
            self.strategy_scores[strategy] = (1 - alpha) * self.strategy_scores[strategy] + alpha * score
    
    def should_continue_reasoning(self):
        """Check if reasoning should continue or terminate."""
        return self.reasoning_steps.item() < self.config.max_reasoning_steps
    
    def forward(self, hidden_states, problem_type=None):
        """
        Forward pass for the adaptive reasoning controller.
        
        Args:
            hidden_states: Hidden states from the transformer model
            problem_type: Optional explicit problem type hint
            
        Returns:
            Modified hidden states with adaptive reasoning applied
        """
        if not self.config.enabled:
            return hidden_states
            
        # Select strategy based on input
        strategy = self.select_strategy(hidden_states, problem_type)
        
        # Apply strategy to modify hidden states
        modified_hidden = self.integrate_strategy(hidden_states, strategy)
        
        return modified_hidden
    
    def get_strategy_stats(self):
        """Get statistics on strategy usage and effectiveness."""
        return {
            "strategy_scores": {str(s): score for s, score in self.strategy_scores.items()},
            "strategy_uses": {str(s): uses for s, uses in self.strategy_uses.items()},
            "current_strategy": str(self.current_strategy),
            "reasoning_steps": self.reasoning_steps.item()
        }

def create_adaptive_config(model_config) -> AdaptiveReasoningConfig:
    """
    Create an adaptive reasoning configuration based on the model configuration
    
    Args:
        model_config: Model configuration
        
    Returns:
        AdaptiveReasoningConfig
    """
    # Extract relevant parameters from model config
    return AdaptiveReasoningConfig(
        low_complexity_threshold=getattr(model_config, 'low_complexity_threshold', 0.3),
        medium_complexity_threshold=getattr(model_config, 'medium_complexity_threshold', 0.7),
        max_computation_budget=getattr(model_config, 'max_computation_budget', 1.0),
        min_computation_budget=getattr(model_config, 'min_computation_budget', 0.2),
        use_early_exit=getattr(model_config, 'use_early_exit', True),
        early_exit_threshold=getattr(model_config, 'early_exit_threshold', 0.9),
        enabled=getattr(model_config, 'enabled', True),
        default_strategy=getattr(model_config, 'default_strategy', ReasoningStrategy.DEFAULT),
        strategy_selection_threshold=getattr(model_config, 'strategy_selection_threshold', 0.7),
        max_reasoning_steps=getattr(model_config, 'max_reasoning_steps', 10),
        use_meta_learning=getattr(model_config, 'use_meta_learning', False),
        use_reinforcement=getattr(model_config, 'use_reinforcement', False),
        temperature=getattr(model_config, 'temperature', 0.8),
        reasoning_prompt_templates=getattr(model_config, 'reasoning_prompt_templates', None),
        strategy_embeddings_size=getattr(model_config, 'strategy_embeddings_size', 128)
    ) 